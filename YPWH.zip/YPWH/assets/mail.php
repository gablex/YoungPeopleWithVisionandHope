<? php
mail('martinkarari@gmail.com',$_POST['subject'],$_POST['message']);
?>
<p>You email has been sent. Please wait and Martin will get back to you within 48 hours.</p>